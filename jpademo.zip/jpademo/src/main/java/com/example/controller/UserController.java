package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Users;
import com.example.repository.UserJpaRepository;
import com.example.repository.UserJpaRepositoryService;

@RestController
@RequestMapping(value = "/users")
public class UserController {

	@Autowired
	UserJpaRepository userJpaRepository;
	
	@Autowired
	UserJpaRepositoryService userJpaRepositoryService;
	
	@GetMapping(value = "/all")
	public List<Users> findAll(){
		return userJpaRepository.findAll();
	}
	
	/*
	 * @GetMapping public Users findByName(@RequestParam(value="name") String name){
	 * return userJpaRepository.findByName(name); }
	 */
	 
	@GetMapping(value = "/getByName/{name}")
	public Users findByName(@PathVariable final String name) {
		return userJpaRepository.findByName(name);
	}
	 
	
	@PostMapping(value = "/load")
	public Users load(@RequestBody final Users users) {
		userJpaRepository.save(users);
		return userJpaRepository.findByName(users.getName());
	}
	
	@GetMapping(value = "/findByTeamName/{teamName}")
	public Users findByTeamName(@PathVariable final String teamName) {
		return userJpaRepository.findByTeamName(teamName);
	}
	
	@GetMapping(value = "/findBySalary/{salary}")
	public List<Users> findBySalary(@PathVariable final String salary) {
		return userJpaRepositoryService.getListBySalary(Integer.parseInt(salary));
	}
	
}
