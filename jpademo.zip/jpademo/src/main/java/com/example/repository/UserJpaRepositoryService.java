package com.example.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.example.entity.Users;

@Component
public class UserJpaRepositoryService {

	@PersistenceContext
	EntityManager entityManager;

	public List<Users> getListBySalary(int salary){
		return entityManager.createNamedQuery("findBySalary",Users.class).setParameter(1, salary).getResultList();
	}
	
}
