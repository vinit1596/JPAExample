package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.example.entity.Users;


@Component
public interface UserJpaRepository extends JpaRepository<Users, Long>{

	Users findByName(String name);
	
	@Query(value = "SELECT * from USERJPADEMO where TEAMNAME = ?1", nativeQuery = true)
	Users findByTeamName(String name);
	
	
}
